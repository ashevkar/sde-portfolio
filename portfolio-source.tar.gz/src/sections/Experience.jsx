import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const jobs = [
  {
    period: 'Aug 2025 — Present',
    role: 'Software Developer',
    company: 'Arizona State University',
    location: 'Tempe, AZ',
    color: '#00f5c4',
    bullets: [
      'Architecting research collaboration platform (TypeScript, Node.js, React) for 100+ concurrent users',
      'Built AI-driven semantic search with Pinecone vector DB + custom embeddings across thousands of research records',
      'Led product lifecycle: requirements, feature design, iterative prototyping for AI workflows',
      'Optimized API performance with AWS Lambda across 5+ production services with full observability',
      'Implemented CI/CD with Vercel + AWS CloudFormation, reducing manual errors significantly',
    ],
    tags: ['TypeScript', 'React', 'Node.js', 'AWS Lambda', 'Pinecone', 'CI/CD'],
  },
  {
    period: 'Mar 2022 — Jun 2023',
    role: 'Software Developer',
    company: 'Anikaay Integration',
    location: 'Pune, India',
    color: '#7b61ff',
    bullets: [
      'Directed microservices migration for 2M users on AWS — reduced load times by 40%',
      'Designed RESTful APIs with Node.js + React integration, improved throughput by 25%',
      'Implemented Docker-based CI/CD pipeline, cutting deployment time by 30% across 10+ services',
      'Mentored 4 junior engineers, resulting in 20% fewer production issues',
      'Achieved 100% quarterly roadmap goals while maintaining 99.9% system availability',
    ],
    tags: ['Node.js', 'AWS', 'Docker', 'React', 'Microservices', 'PostgreSQL'],
  },
  {
    period: 'Aug 2020 — Mar 2022',
    role: 'Software Developer',
    company: 'GlobalStep',
    location: 'Pune, India',
    color: '#ff6b6b',
    bullets: [
      'Led full-stack development of React/Redux customer portal — 4 major releases in year one',
      'Integrated secure payment gateways enabling 1,000+ successful monthly transactions',
      'Optimized PostgreSQL schemas — reduced data retrieval latency to under 200ms',
      'Authored Swagger API docs cutting new engineer onboarding time to 3 days',
      'Resolved 40+ complex Tier-3 production tickets while maintaining strict SLAs',
    ],
    tags: ['React', 'Redux', 'PostgreSQL', 'JUnit', 'REST APIs', 'Bitbucket'],
  },
];

function JobCard({ job, index }) {
  const ref = useRef();
  const inView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, x: index % 2 === 0 ? -60 : 60 }}
      animate={inView ? { opacity: 1, x: 0 } : {}}
      transition={{ duration: 0.7, ease: 'easeOut' }}
      style={{ display: 'grid', gridTemplateColumns: '200px 1fr', gap: '2rem', marginBottom: '3rem' }}
    >
      <div style={{ textAlign: 'right', paddingTop: '4px' }}>
        <div style={{ fontFamily: 'DM Mono', fontSize: '0.7rem', color: job.color, marginBottom: '0.5rem' }}>
          {job.period}
        </div>
        <div style={{ fontSize: '0.75rem', color: '#6b7280', fontFamily: 'DM Mono' }}>{job.location}</div>
      </div>

      <div style={{ position: 'relative', paddingLeft: '2rem' }}>
        {/* Timeline line */}
        <div style={{
          position: 'absolute', left: 0, top: 0, bottom: 0,
          width: '1px', background: `linear-gradient(to bottom, ${job.color}, transparent)`,
        }} />
        <div style={{
          position: 'absolute', left: '-5px', top: '6px',
          width: '11px', height: '11px', borderRadius: '50%',
          background: job.color, boxShadow: `0 0 12px ${job.color}`,
        }} />

        <div className="glass-card" style={{ padding: '1.8rem' }}>
          <h3 style={{ fontSize: '1.2rem', fontWeight: 700, marginBottom: '4px' }}>{job.role}</h3>
          <p style={{ fontFamily: 'DM Mono', fontSize: '0.8rem', color: job.color, marginBottom: '1.2rem' }}>{job.company}</p>
          <ul style={{ listStyle: 'none', marginBottom: '1.2rem' }}>
            {job.bullets.map((b, i) => (
              <li key={i} style={{ fontSize: '0.875rem', color: '#9ca3af', lineHeight: 1.7, marginBottom: '0.4rem', display: 'flex', gap: '8px' }}>
                <span style={{ color: job.color, flexShrink: 0 }}>▸</span>
                {b}
              </li>
            ))}
          </ul>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
            {job.tags.map(t => (
              <span key={t} className="tag" style={{ borderColor: `${job.color}33`, color: job.color, background: `${job.color}10` }}>
                {t}
              </span>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
}

export default function Experience() {
  const ref = useRef();
  const inView = useInView(ref, { once: true });

  return (
    <section id="experience" style={{ padding: '8rem 8%' }}>
      <motion.div ref={ref} initial={{ opacity: 0, y: 30 }} animate={inView ? { opacity: 1, y: 0 } : {}} transition={{ duration: 0.6 }}>
        <p className="section-label">02 — Experience</p>
        <h2 style={{ fontSize: 'clamp(2.2rem, 5vw, 3.5rem)', fontWeight: 800, marginBottom: '4rem' }}>
          Where I've <span style={{ color: '#00f5c4' }}>Built</span>
        </h2>
      </motion.div>

      {jobs.map((job, i) => <JobCard key={i} job={job} index={i} />)}
    </section>
  );
}
