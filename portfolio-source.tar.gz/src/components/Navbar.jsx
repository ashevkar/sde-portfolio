import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const links = ['About', 'Experience', 'Projects', 'Skills', 'Contact'];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const scrollTo = (id) => {
    document.getElementById(id.toLowerCase())?.scrollIntoView({ behavior: 'smooth' });
    setOpen(false);
  };

  return (
    <motion.nav
      initial={{ y: -80 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: 'easeOut' }}
      style={{
        position: 'fixed', top: 0, left: 0, right: 0, zIndex: 1000,
        padding: '1.2rem 3rem',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        background: scrolled ? 'rgba(5,8,16,0.85)' : 'transparent',
        backdropFilter: scrolled ? 'blur(20px)' : 'none',
        borderBottom: scrolled ? '1px solid rgba(255,255,255,0.06)' : 'none',
        transition: 'all 0.4s ease',
      }}
    >
      <motion.div
        whileHover={{ scale: 1.05 }}
        style={{ fontFamily: 'DM Mono', fontSize: '0.85rem', color: '#00f5c4', letterSpacing: '0.1em', cursor: 'pointer' }}
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
      >
        AS<span style={{ color: '#e8eaf6' }}>._</span>
      </motion.div>

      <div style={{ display: 'flex', gap: '2.5rem', alignItems: 'center' }}>
        {links.map((l, i) => (
          <motion.button
            key={l}
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * i + 0.3 }}
            onClick={() => scrollTo(l)}
            style={{
              background: 'none', border: 'none', cursor: 'pointer',
              fontFamily: 'DM Mono', fontSize: '0.72rem',
              color: '#6b7280', letterSpacing: '0.15em',
              transition: 'color 0.2s',
              textTransform: 'uppercase',
            }}
            whileHover={{ color: '#00f5c4' }}
          >
            {String(i + 1).padStart(2, '0')}. {l}
          </motion.button>
        ))}
        <motion.a
          href="mailto:ashshevkar@gmail.com"
          whileHover={{ scale: 1.05, boxShadow: '0 0 20px rgba(0,245,196,0.4)' }}
          style={{
            fontFamily: 'DM Mono', fontSize: '0.72rem', letterSpacing: '0.1em',
            color: '#00f5c4', border: '1px solid rgba(0,245,196,0.4)',
            borderRadius: '6px', padding: '8px 18px', textDecoration: 'none',
          }}
        >
          Hire Me
        </motion.a>
      </div>
    </motion.nav>
  );
}
